from .main import TvDatafeed, Interval

__version__ = "2.1.0"
