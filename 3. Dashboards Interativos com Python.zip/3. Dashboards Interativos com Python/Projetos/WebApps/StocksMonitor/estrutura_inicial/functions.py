import pandas as pd
import numpy as np
from pandas.tseries.offsets import DateOffset
from datetime import date
from tvDatafeed.main import TvDatafeed