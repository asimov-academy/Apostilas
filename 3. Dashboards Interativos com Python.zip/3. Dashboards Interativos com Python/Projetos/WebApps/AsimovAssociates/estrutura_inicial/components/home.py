import dash
from dash import html, dcc, callback_context
from dash.dependencies import Input, Output, State
import dash_bootstrap_components as dbc
import pandas as pd

from dash import dash_table
from dash.dash_table.Format import Group

from app import app
from components import modal_novo_processo, modal_novo_advogado, modal_advogados


# ========= Styles ========= #


# Funções para gerar os Cards =======================
# Checar o DataFrame e gerar os icones


# Card padrão de contagem


# Card qualquer de processo


# ========= Layout ========= #
layout = dbc.Container([])



# ======= Callbacks ======== #
# Callback pra atualizar o dropdown de advogados


# Callback pra atualizar o dropdown de clientes


# Callback pra atualizar o dropdown de processos


# Callback pra gerar o conteudo dos cards

