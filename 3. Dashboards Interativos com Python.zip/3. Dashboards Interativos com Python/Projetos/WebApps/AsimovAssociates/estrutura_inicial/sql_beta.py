import pandas as pd
import sqlite3

# Criando o Conn
